function toggle() {
	const header = document.querySelector('.wadah-menu');
	header.classList.toggle('mobile');
}